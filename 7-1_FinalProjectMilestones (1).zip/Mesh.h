#pragma once

#include <glad/glad.h>
#include <glm/glm.hpp>

struct GLMesh {
    GLuint vao;
    GLuint vbo;
    GLuint ebo;
    GLuint textureId;
    GLsizei numIndices;

    glm::vec3 position = glm::vec3(0.0f);
    glm::vec3 rotation = glm::vec3(0.0f);
    glm::vec3 scale = glm::vec3(1.0f);
};

