#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "ShaderManager.h"

#include <fstream>
#include <sstream>
#include <iostream>
#include <glm/gtc/type_ptr.hpp>

// ---------------- local helpers (file-scope, not class members)
static GLuint CompileShader_GL(unsigned int shaderType, const std::string& source) {
    GLuint id = glCreateShader(shaderType);
    const char* src = source.c_str();
    glShaderSource(id, 1, &src, nullptr);
    glCompileShader(id);

    GLint ok = GL_FALSE;
    glGetShaderiv(id, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        GLint len = 0; glGetShaderiv(id, GL_INFO_LOG_LENGTH, &len);
        std::string log(len, '\0');
        glGetShaderInfoLog(id, len, nullptr, &log[0]);
        std::cerr << "SHADER COMPILE FAILED:\n" << log << "\n";
        glDeleteShader(id);
        return 0;
    }
    return id;
}

static bool Link_GL(GLuint program) {
    glLinkProgram(program);
    GLint ok = GL_FALSE; glGetProgramiv(program, GL_LINK_STATUS, &ok);
    if (!ok) {
        GLint len = 0; glGetProgramiv(program, GL_INFO_LOG_LENGTH, &len);
        std::string log(len, '\0');
        glGetProgramInfoLog(program, len, nullptr, &log[0]);
        std::cerr << "PROGRAM LINK FAILED:\n" << log << "\n";
        return false;
    }
    return true;
}

// ---------------- ShaderManager impl
ShaderManager::ShaderManager() : m_shaderProgram(0) {}
ShaderManager::~ShaderManager() {}  // keep empty; GL context may be gone at shutdown

bool ShaderManager::LoadShaderProgram(const std::string& vertexPath, const std::string& fragmentPath) {
    // header declares ReadFile(const char*), so pass c_str()
    std::string vsrc = ReadFile(vertexPath.c_str());
    std::string fsrc = ReadFile(fragmentPath.c_str());

    if (vsrc.empty() || fsrc.empty()) {
        std::cerr << "ERROR: Shader source is empty. Vertex path: " << vertexPath
            << ", Fragment path: " << fragmentPath << "\n";
        return false;
    }

    GLuint vs = CompileShader_GL(GL_VERTEX_SHADER, vsrc);
    GLuint fs = CompileShader_GL(GL_FRAGMENT_SHADER, fsrc);
    if (!vs || !fs) return false;

    m_shaderProgram = glCreateProgram();
    glAttachShader(m_shaderProgram, vs);
    glAttachShader(m_shaderProgram, fs);
    bool linked = Link_GL(m_shaderProgram);

    glDeleteShader(vs);
    glDeleteShader(fs);
    return linked;
}

void ShaderManager::UseShader() { glUseProgram(m_shaderProgram); }

std::string ShaderManager::ReadFile(const char* filePath) {
    std::ifstream file(filePath, std::ios::in);
    if (!file.is_open()) {
        std::cerr << "ERROR: could not open file: " << filePath << "\n";
        return {};
    }
    std::ostringstream ss; ss << file.rdbuf();
    return ss.str();
}

// ---------- Uniform setters
void ShaderManager::SetMat4Value(const std::string& name, const glm::mat4& mat) {
    GLint loc = glGetUniformLocation(m_shaderProgram, name.c_str());
    if (loc != -1) glUniformMatrix4fv(loc, 1, GL_FALSE, glm::value_ptr(mat));
}
void ShaderManager::SetVec4Value(const std::string& name, const glm::vec4& v) {
    GLint loc = glGetUniformLocation(m_shaderProgram, name.c_str());
    if (loc != -1) glUniform4fv(loc, 1, glm::value_ptr(v));
}
void ShaderManager::SetVec3Value(const std::string& name, const glm::vec3& v) {
    GLint loc = glGetUniformLocation(m_shaderProgram, name.c_str());
    if (loc != -1) glUniform3fv(loc, 1, glm::value_ptr(v));
}
void ShaderManager::SetVec2Value(const std::string& name, const glm::vec2& v) {
    GLint loc = glGetUniformLocation(m_shaderProgram, name.c_str());
    if (loc != -1) glUniform2fv(loc, 1, glm::value_ptr(v));
}
void ShaderManager::SetIntValue(const std::string& name, int value) {
    GLint loc = glGetUniformLocation(m_shaderProgram, name.c_str());
    if (loc != -1) glUniform1i(loc, value);
}
void ShaderManager::SetFloatValue(const std::string& name, float value) {
    GLint loc = glGetUniformLocation(m_shaderProgram, name.c_str());
    if (loc != -1) glUniform1f(loc, value);
}

