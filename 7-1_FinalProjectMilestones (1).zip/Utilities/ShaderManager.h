#ifndef SHADERMANAGER_H
#define SHADERMANAGER_H

#include <string>
#include <glm/glm.hpp>

using GLuint = unsigned int;
using GLint = int;

class ShaderManager {
public:
    ShaderManager();
    ~ShaderManager();

    // names used by MainCode/ViewManager/SceneManager
    bool LoadShaderProgram(const std::string& vertexPath, const std::string& fragmentPath);
    void UseShader();

    void SetMat4Value(const std::string& name, const glm::mat4& mat);
    void SetVec3Value(const std::string& name, const glm::vec3& vec);
    void SetVec4Value(const std::string& name, const glm::vec4& vec);
    void SetVec2Value(const std::string& name, const glm::vec2& vec);
    void SetIntValue(const std::string& name, int value);
    void SetFloatValue(const std::string& name, float value);
    void SetSampler2DValue(const std::string& name, int textureSlot); // just calls SetIntValue

private:
    std::string ReadFile(const char* filePath);
    GLuint Compile(unsigned int shaderType, const std::string& source);
    bool   Link(GLuint program);

    GLuint m_shaderProgram;
};

#endif

