﻿#pragma once
#include <string>
#include <glad/glad.h>
#include <glm/glm.hpp>

class ShaderManager {
public:
    ShaderManager();
    ~ShaderManager();  // defined in .cpp

    // Build & use program
    bool LoadShaderProgram(const std::string& vertexPath, const std::string& fragmentPath);
    void UseShader();

    // Uniform setters
    void SetMat4Value(const std::string& name, const glm::mat4& mat);
    void SetVec3Value(const std::string& name, const glm::vec3& vec);
    void SetVec4Value(const std::string& name, const glm::vec4& vec);
    void SetVec2Value(const std::string& name, const glm::vec2& vec);
    void SetIntValue(const std::string& name, int value);
    void SetFloatValue(const std::string& name, float value);
    inline void SetSampler2DValue(const std::string& name, int textureSlot) { SetIntValue(name, textureSlot); }

private:
    // NOTE: header stays with const char* to match your original project
    std::string ReadFile(const char* filePath);

    GLuint m_shaderProgram = 0;
};
