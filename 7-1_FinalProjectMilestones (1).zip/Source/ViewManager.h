///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

struct GLFWwindow;  // forward declare

class ViewManager {
public:
    ViewManager();
    ~ViewManager();

    bool Initialize();        // optional if you use it
    void UpdateView();        // must match exactly

    static void Mouse_Position_Callback(GLFWwindow* window, double xpos, double ypos);

private:
    GLFWwindow* m_pWindow = nullptr;
};
