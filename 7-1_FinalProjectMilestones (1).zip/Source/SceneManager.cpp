﻿///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp  — separated props, grunge floor, wood table, monitor, lamp
///////////////////////////////////////////////////////////////////////////////

#include <glad/glad.h>
#include "SceneManager.h"
#include "ShaderManager.h"
#include "ShapeMeshes.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/gtx/transform.hpp>
#include <iostream>
#include <string>

// ---- uniform names used in your shaders
namespace {
    const char* U_MODEL = "model";
    const char* U_COLOR = "objectColor";
    const char* U_OBJECT_TEXTURE = "objectTexture";
    const char* U_USE_TEXTURE = "bUseTexture";
}

// ====== Layout (easy to tweak) =============================================
namespace layout {
    // Table
    const glm::vec3 tableTopPos = { 0.0f, 1.20f,  0.0f };

    // Monitor (center/back a bit)
    const glm::vec3 monBasePos = { 0.30f, 1.20f, -0.25f };
    const glm::vec3 monStandPos = { 0.30f, 1.55f, -0.25f };
    const glm::vec3 monScreenPos = { 0.30f, 2.05f, -0.25f };
    const float     monScreenYaw = 0.0f;

    // Lamp — push farther to the FRONT-LEFT corner
    const glm::vec3 lampBasePos = { -1.85f, 1.22f,  1.15f };
    const glm::vec3 lampPolePos = { -1.85f, 1.57f,  1.15f };
    const glm::vec3 lampShadePos = { -1.85f, 2.00f,  1.15f };

    // Mug — pull a little toward the center so it’s clear of the lamp
    const glm::vec3 mugBodyPos = { -1.10f, 1.22f,  0.60f };
    const glm::vec3 mugHandlePos = { -0.85f, 1.22f,  0.60f }; // keep ~0.25 to the right of the body

    // Notebook (front-right)
    const glm::vec3 bookPos = { 1.45f, 1.22f, -0.45f };
}


SceneManager::SceneManager(ShaderManager* pShaderManager)
    : m_pShaderManager(pShaderManager), m_basicMeshes(new ShapeMeshes()), m_loadedTextures(0) {}

SceneManager::~SceneManager() {
    delete m_basicMeshes; m_basicMeshes = nullptr;
    m_pShaderManager = nullptr;
}

// ------------------------------- textures
bool SceneManager::CreateGLTexture(const char* filename, std::string tag) {
    int w = 0, h = 0, c = 0;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* img = stbi_load(filename, &w, &h, &c, STBI_rgb_alpha);
    if (!img) { std::cout << "Could not load image: " << filename << "\n"; return false; }

    GLuint tex = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, img);
    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(img);
    glBindTexture(GL_TEXTURE_2D, 0);

    m_textureIDs[m_loadedTextures] = { tex, tag };
    ++m_loadedTextures;
    return true;
}

void SceneManager::BindGLTextures() {
    for (int i = 0; i < m_loadedTextures; ++i) {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}
void SceneManager::DestroyGLTextures() {
    for (int i = 0; i < m_loadedTextures; ++i) glDeleteTextures(1, &m_textureIDs[i].ID);
    m_loadedTextures = 0;
}
int  SceneManager::FindTextureID(std::string tag) { for (int i = 0; i < m_loadedTextures; ++i) if (m_textureIDs[i].tag == tag) return m_textureIDs[i].ID; return -1; }
int  SceneManager::FindTextureSlot(std::string tag) { for (int i = 0; i < m_loadedTextures; ++i) if (m_textureIDs[i].tag == tag) return i; return -1; }
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& m) {
    for (auto& x : m_objectMaterials) if (x.tag == tag) { m = x; return true; } return false;
}

// ------------------------------- uniform helpers
void SceneManager::SetTransformations(glm::vec3 s, float rx, float ry, float rz, glm::vec3 p) {
    glm::mat4 M = glm::translate(p)
        * glm::rotate(glm::radians(rx), glm::vec3(1, 0, 0))
        * glm::rotate(glm::radians(ry), glm::vec3(0, 1, 0))
        * glm::rotate(glm::radians(rz), glm::vec3(0, 0, 1))
        * glm::scale(s);
    m_pShaderManager->SetMat4Value(U_MODEL, M);
}
void SceneManager::SetShaderColor(float r, float g, float b, float a) {
    m_pShaderManager->SetIntValue(U_USE_TEXTURE, false);
    m_pShaderManager->SetVec4Value(U_COLOR, glm::vec4(r, g, b, a));
}
void SceneManager::SetShaderTexture(std::string tag) {
    m_pShaderManager->SetIntValue(U_USE_TEXTURE, true);
    m_pShaderManager->SetIntValue(U_OBJECT_TEXTURE, FindTextureSlot(tag));
}
void SceneManager::SetTextureUVScale(float u, float v) { m_pShaderManager->SetVec2Value("UVscale", glm::vec2(u, v)); }
void SceneManager::SetShaderMaterial(std::string tag) {
    OBJECT_MATERIAL m{};
    if (FindMaterial(tag, m)) {
        m_pShaderManager->SetVec3Value("material.diffuseColor", m.diffuseColor);
        m_pShaderManager->SetVec3Value("material.specularColor", m.specularColor);
        m_pShaderManager->SetFloatValue("material.shininess", m.shininess);
    }
}

// ------------------------------- lighting
void SceneManager::SetLighting(const glm::vec3& camPos)
{
    m_pShaderManager->SetVec3Value("viewPosition", camPos);

    // Directional key (warm neutral)
    m_pShaderManager->SetIntValue("directionalLight.bActive", 1);
    m_pShaderManager->SetVec3Value("directionalLight.direction", glm::vec3(-0.7f, -1.0f, -0.3f));
    m_pShaderManager->SetVec3Value("directionalLight.ambient", glm::vec3(0.12f, 0.10f, 0.08f));
    m_pShaderManager->SetVec3Value("directionalLight.diffuse", glm::vec3(0.95f, 0.86f, 0.76f));
    m_pShaderManager->SetVec3Value("directionalLight.specular", glm::vec3(1.0f));

    // Neutral point fill
    m_pShaderManager->SetIntValue("pointLights[0].bActive", 1);
    m_pShaderManager->SetVec3Value("pointLights[0].position", glm::vec3(2.0f, 2.5f, 2.0f));
    m_pShaderManager->SetVec3Value("pointLights[0].ambient", glm::vec3(0.05f));
    m_pShaderManager->SetVec3Value("pointLights[0].diffuse", glm::vec3(0.35f));
    m_pShaderManager->SetVec3Value("pointLights[0].specular", glm::vec3(0.45f));
    m_pShaderManager->SetFloatValue("pointLights[0].constant", 1.0f);
    m_pShaderManager->SetFloatValue("pointLights[0].linear", 0.09f);
    m_pShaderManager->SetFloatValue("pointLights[0].quadratic", 0.032f);

    for (int i = 1; i < 5; ++i)
        m_pShaderManager->SetIntValue(("pointLights[" + std::to_string(i) + "].bActive").c_str(), 0);
    m_pShaderManager->SetIntValue("spotLight.bActive", 0);
}

// ------------------------------- scene setup
void SceneManager::PrepareScene() {
    // Meshes
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCubeMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadTorusMesh();

    // Textures
    CreateGLTexture("Utilities/textures/wood_planks.jpg", "wood");
    CreateGLTexture("Utilities/textures/brushed_metal.png", "metal");
    CreateGLTexture("Utilities/textures/grunge_overlay.png", "grunge");
    // optional
    CreateGLTexture("Utilities/textures/mug_ceramic.png", "ceramic");
    CreateGLTexture("Utilities/textures/screen_texture.png", "screen");

    BindGLTextures();

    // Materials
    m_objectMaterials.clear();
    m_objectMaterials.push_back(OBJECT_MATERIAL{ "woodMat",    {1,1,1}, 0.2f, {1,1,1},   {0.25f,0.25f,0.25f}, 32.0f });
    m_objectMaterials.push_back(OBJECT_MATERIAL{ "metalMat",   {1,1,1}, 0.2f, {0.9f,0.9f,0.9f}, {1,1,1},       96.0f });
    m_objectMaterials.push_back(OBJECT_MATERIAL{ "ceramicMat", {1,1,1}, 0.2f, {1.0f,1.0f,1.0f}, {0.5f,0.5f,0.5f}, 48.0f });
}

// ------------------------------- draw
void SceneManager::RenderScene() {
    auto UseTexture = [&](const char* preferred, const char* fallback) {
        int slot = FindTextureSlot(preferred);
        if (slot < 0 && fallback) slot = FindTextureSlot(fallback);
        m_pShaderManager->SetIntValue(U_USE_TEXTURE, 1);
        m_pShaderManager->SetIntValue(U_OBJECT_TEXTURE, (slot >= 0) ? slot : 0);
        };

    glm::vec3 scale, pos;
    float rx = 0, ry = 0, rz = 0;

    // ===== FLOOR — grunge
    scale = { 20.0f, 1.0f, 20.0f };
    pos = { 0.0f, 0.0f,  0.0f };
    SetTransformations(scale, rx, ry, rz, pos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("grunge", "wood");
    SetTextureUVScale(10.0f, 10.0f);
    m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(1.0f));
    m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(0.08f));
    m_pShaderManager->SetFloatValue("material.shininess", 8.0f);
    m_basicMeshes->DrawPlaneMesh();
    SetTextureUVScale(1.0f, 1.0f);

    // ===== TABLE: top + rails + legs
    // Top (wood)
    scale = { 4.0f, 0.20f, 2.5f };
    pos = layout::tableTopPos;
    SetTransformations(scale, 0, 0, 0, pos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("wood", nullptr);
    SetTextureUVScale(3.0f, 3.0f);
    m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(1.0f));
    m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(0.30f));
    m_pShaderManager->SetFloatValue("material.shininess", 40.0f);
    m_basicMeshes->DrawCubeMesh();
    SetTextureUVScale(1.0f, 1.0f);

    // Rails (wood)
    auto Rail = [&](glm::vec3 s, glm::vec3 p) {
        SetTransformations(s, 0, 0, 0, p);
        m_pShaderManager->SetIntValue("bUseLighting", 1);
        UseTexture("wood", nullptr);
        SetTextureUVScale(2.0f, 2.0f);
        m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(1.0f));
        m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(0.28f));
        m_pShaderManager->SetFloatValue("material.shininess", 36.0f);
        m_basicMeshes->DrawCubeMesh();
        SetTextureUVScale(1.0f, 1.0f);
        };
    Rail({ 4.2f, 0.15f, 0.15f }, { 0.0f, 1.05f,  1.25f });
    Rail({ 4.2f, 0.15f, 0.15f }, { 0.0f, 1.05f, -1.25f });
    Rail({ 0.15f, 0.15f, 2.60f }, { 2.05f, 1.05f,  0.0f });
    Rail({ 0.15f, 0.15f, 2.60f }, { -2.05f, 1.05f,  0.0f });

    // Legs (metal)
    auto Leg = [&](float x, float z) {
        SetTransformations({ 0.20f, 1.20f, 0.20f }, 0, 0, 0, { x, 0.60f, z });
        m_pShaderManager->SetIntValue("bUseLighting", 1);
        UseTexture("metal", "wood");
        m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(0.9f));
        m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(1.0f));
        m_pShaderManager->SetFloatValue("material.shininess", 96.0f);
        m_basicMeshes->DrawCubeMesh();
        };
    Leg(-1.7f, -1.0f); Leg(1.7f, -1.0f); Leg(-1.7f, 1.0f); Leg(1.7f, 1.0f);

    // ===== Objects on table (SEPARATED)

    // --- Monitor base (metal)
    SetTransformations({ 0.25f, 0.06f, 0.25f }, 0, 0, 0, layout::monBasePos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("metal", "wood");
    m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(0.9f));
    m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(1.0f));
    m_pShaderManager->SetFloatValue("material.shininess", 96.0f);
    m_basicMeshes->DrawCylinderMesh();

    // --- Monitor stand (metal)
    SetTransformations({ 0.05f, 0.70f, 0.05f }, 0, 0, 0, layout::monStandPos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("metal", "wood");
    m_basicMeshes->DrawCylinderMesh();

    // --- Monitor screen (thin box) — facing camera
    SetTransformations({ 1.4f, 0.85f, 0.07f }, 0.0f, layout::monScreenYaw, 0.0f, layout::monScreenPos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("screen", "metal");
    SetTextureUVScale(1.0f, 1.0f);
    m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(1.0f));
    m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(0.25f));
    m_pShaderManager->SetFloatValue("material.shininess", 32.0f);
    m_basicMeshes->DrawCubeMesh();

    // --- Mug body (ceramic)
    SetTransformations({ 0.42f, 0.45f, 0.42f }, 0, 0, 0, layout::mugBodyPos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("ceramic", "metal");
    m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(1.0f));
    m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(0.5f));
    m_pShaderManager->SetFloatValue("material.shininess", 48.0f);
    m_basicMeshes->DrawCylinderMesh();

    // --- Mug handle (torus, ceramic)
    SetTransformations({ 0.16f, 0.16f, 0.16f }, 0, 0, 90.0f, layout::mugHandlePos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("ceramic", "metal");
    m_basicMeshes->DrawTorusMesh();

    // --- Notebook
    SetTransformations({ 0.9f, 0.04f, 0.7f }, 0, 0, 0, layout::bookPos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("wood", nullptr);
    SetTextureUVScale(1.0f, 1.0f);
    m_pShaderManager->SetVec3Value("material.diffuseColor", glm::vec3(1.0f));
    m_pShaderManager->SetVec3Value("material.specularColor", glm::vec3(0.20f));
    m_pShaderManager->SetFloatValue("material.shininess", 24.0f);
    m_basicMeshes->DrawCubeMesh();

    // --- Lamp base (front-left corner)
    SetTransformations({ 0.28f, 0.05f, 0.28f }, 0, 0, 0, layout::lampBasePos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("metal", "wood");
    m_basicMeshes->DrawCylinderMesh();

    // --- Lamp pole
    SetTransformations({ 0.05f, 0.70f, 0.05f }, 0, 0, 0, layout::lampPolePos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("metal", "wood");
    m_basicMeshes->DrawCylinderMesh();

    // --- Lamp shade (flipped cone)
    SetTransformations({ 0.5f, 0.35f, 0.5f }, -180.0f, 0.0f, 0.0f, layout::lampShadePos);
    m_pShaderManager->SetIntValue("bUseLighting", 1);
    UseTexture("ceramic", "metal");
    m_basicMeshes->DrawConeMesh();

    SetTextureUVScale(1.0f, 1.0f);
}

