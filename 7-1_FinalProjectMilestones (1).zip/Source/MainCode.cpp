///////////////////////////////////////////////////////////////////////////////
// maincode.cpp
// ============
// initializes GLAD/GLFW, loads shaders, sets up camera + scene, main loop
///////////////////////////////////////////////////////////////////////////////

#define GLFW_INCLUDE_NONE
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>

#include "ShaderManager.h"
#include "SceneManager.h"
#include "ViewManager.h"

// globals used by ViewManager via extern
ShaderManager g_shaderManager;
SceneManager  g_sceneManager(&g_shaderManager);

static const char* VERT_PATH = "Utilities/shaders/vertexShader.glsl";
static const char* FRAG_PATH = "Utilities/shaders/fragmentShader.glsl";

static void glfw_error_callback(int code, const char* desc) {
    std::cerr << "GLFW ERROR [" << code << "]: " << desc << "\n";
}

int main() {
    glfwSetErrorCallback(glfw_error_callback);
    if (!glfwInit()) return -1;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(800, 600, "CS330 Final Project", nullptr, nullptr);
    if (!window) { glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // vsync

    // load GL first
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to load GLAD\n";
        glfwTerminate();
        return -1;
    }

    // viewport + resize
    int fbw = 0, fbh = 0;
    glfwGetFramebufferSize(window, &fbw, &fbh);
    glViewport(0, 0, fbw, fbh);
    glfwSetFramebufferSizeCallback(window, [](GLFWwindow*, int w, int h) {
        glViewport(0, 0, w, h);
        });

    // simple ESC to close
    glfwSetKeyCallback(window, [](GLFWwindow* win, int key, int, int action, int) {
        if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) glfwSetWindowShouldClose(win, GLFW_TRUE);
        });

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.05f, 0.05f, 0.06f, 1.0f);

    if (!g_shaderManager.LoadShaderProgram(VERT_PATH, FRAG_PATH)) {
        std::cerr << "Failed to load/link shaders.\n";
        glfwTerminate();
        return -1;
    }
    g_shaderManager.UseShader();

    // texture samplers (match your fragment shader)
    g_shaderManager.SetIntValue("objectTexture", 0);
    // if you have an overlay sampler in your shader, keep this; otherwise it�s harmless:
    g_shaderManager.SetIntValue("overlayTexture", 1);

    // --- camera / view
    ViewManager viewManager;
    if (!viewManager.Initialize()) {
        std::cerr << "ViewManager.Initialize() failed (no current window?).\n";
        glfwTerminate();
        return -1;
    }

    // set initial view/projection + lights before building scene
    viewManager.UpdateView();

    // --- scene
    g_sceneManager.PrepareScene();

    // --- main loop
    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        g_shaderManager.UseShader();
        viewManager.UpdateView();   // updates view/proj uniforms + lighting each frame
        g_sceneManager.RenderScene();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
