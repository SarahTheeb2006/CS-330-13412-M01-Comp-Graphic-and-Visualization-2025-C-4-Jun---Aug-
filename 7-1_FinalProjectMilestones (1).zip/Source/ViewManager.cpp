#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "ViewManager.h"
#include "ShaderManager.h"
#include "SceneManager.h"

extern ShaderManager g_shaderManager;
extern SceneManager  g_sceneManager;

// ---------- camera state ----------
namespace {
    // Start the camera like your original scene so you definitely see the table
    glm::vec3 camPos = { 3.0f, 3.0f, 6.0f };
    glm::vec3 camFront = glm::normalize(glm::vec3(0.0f, 1.2f, 0.0f) - camPos); // look at table
    glm::vec3 camUp = { 0.0f, 1.0f, 0.0f };

    // derive yaw/pitch from the initial front vector
    float yaw = glm::degrees(atan2f(camFront.z, camFront.x));                 // [-180..180]
    float pitch = glm::degrees(asinf(camFront.y));                              // [-90..90]

    // input/timing
    float moveSpeed = 3.0f;    // mouse wheel scales this
    const float mouseSens = 0.12f;
    bool  firstMouse = true;
    double lastX = 400.0, lastY = 300.0;

    double lastTime = 0.0;

    // projection toggle
    bool  usePerspective = true;
    bool  toggleLatch = false;   // edge detect for 'P'
}

ViewManager::ViewManager() : m_pWindow(nullptr) {}
ViewManager::~ViewManager() = default;

bool ViewManager::Initialize()
{
    m_pWindow = glfwGetCurrentContext();
    if (!m_pWindow) return false;

    // IMPORTANT: do NOT disable the cursor by default (some remote labs blank input)
    // If you want capture later, uncomment:
    // glfwSetInputMode(m_pWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glfwSetCursorPosCallback(m_pWindow, ViewManager::Mouse_Position_Callback);

    // Mouse wheel => speed
    glfwSetScrollCallback(m_pWindow, [](GLFWwindow*, double /*xoff*/, double yoff) {
        moveSpeed += static_cast<float>(yoff) * 0.5f;
        if (moveSpeed < 0.1f) moveSpeed = 0.1f;
        if (moveSpeed > 20.0f) moveSpeed = 20.0f;
        });

    lastTime = glfwGetTime();
    return true;
}

void ViewManager::UpdateView()
{
    if (!m_pWindow) return;

    // ---- timing (clamp crazy dt spikes)
    const double now = glfwGetTime();
    float dt = static_cast<float>(now - lastTime);
    if (dt > 0.1f) dt = 0.1f;
    lastTime = now;

    // ---- keyboard translate (WASD + Q/E)
    const glm::vec3 worldUp(0, 1, 0);
    glm::vec3 right = glm::normalize(glm::cross(camFront, worldUp));

    float v = moveSpeed * dt;
    if (glfwGetKey(m_pWindow, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) v *= 2.0f;

    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS) camPos += camFront * v;
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS) camPos -= camFront * v;
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS) camPos -= right * v;
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS) camPos += right * v;
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS) camPos += worldUp * v;
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS) camPos -= worldUp * v;

    // ---- projection toggle (P)
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS) {
        if (!toggleLatch) { usePerspective = !usePerspective; toggleLatch = true; }
    }
    else {
        toggleLatch = false;
    }

    // ---- recompute camera basis
    right = glm::normalize(glm::cross(camFront, worldUp));
    camUp = glm::normalize(glm::cross(right, camFront));

    glm::mat4 view = glm::lookAt(camPos, camPos + camFront, camUp);

    int fbw = 0, fbh = 0;
    glfwGetFramebufferSize(m_pWindow, &fbw, &fbh);
    if (fbw <= 0) fbw = 800;
    if (fbh <= 0) fbh = 600;
    float aspect = (float)fbw / (float)fbh;

    glm::mat4 proj(1.0f);
    if (usePerspective) {
        proj = glm::perspective(glm::radians(45.0f), aspect, 0.1f, 100.0f);
    }
    else {
        float orthoScale = 4.0f;
        proj = glm::ortho(-orthoScale * aspect, orthoScale * aspect,
            -orthoScale, orthoScale,
            0.1f, 100.0f);
    }

    // ---- upload + keep lights in sync
    g_shaderManager.UseShader();
    g_shaderManager.SetMat4Value("view", view);
    g_shaderManager.SetMat4Value("projection", proj);
    g_shaderManager.SetVec3Value("viewPosition", camPos);

    g_sceneManager.SetLighting(camPos);
}

void ViewManager::Mouse_Position_Callback(GLFWwindow* /*window*/, double xpos, double ypos)
{
    if (firstMouse) { lastX = xpos; lastY = ypos; firstMouse = false; return; }

    float xoffset = static_cast<float>(xpos - lastX);
    float yoffset = static_cast<float>(lastY - ypos); // invert Y
    lastX = xpos; lastY = ypos;

    xoffset *= mouseSens;
    yoffset *= mouseSens;

    yaw += xoffset;
    pitch += yoffset;
    if (pitch > 89.0f)  pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    camFront = glm::normalize(front);
}
