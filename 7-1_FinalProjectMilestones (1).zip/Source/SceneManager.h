///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ==============
// Manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Modified by Student for Milestone Five: Lighting + Texturing
///////////////////////////////////////////////////////////////////////////////
#pragma once
#include <string>
#include <vector>
#include <glm/glm.hpp>
typedef unsigned int GLuint;

class ShaderManager;
class ShapeMeshes;

struct OBJECT_MATERIAL {
    std::string tag;
    glm::vec3   ambientColor{ 1.0f, 1.0f, 1.0f }; // kept for completeness
    float       ambientStrength{ 0.2f };
    glm::vec3   diffuseColor{ 1.0f, 1.0f, 1.0f };
    glm::vec3   specularColor{ 0.0f, 0.0f, 0.0f };
    float       shininess{ 8.0f };
};

class SceneManager {
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    void PrepareScene();
    void RenderScene();

    // update lights each frame (pass camera position from ViewManager)
    void SetLighting(const glm::vec3& camPos);

    void SetTransformations(glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    void SetShaderColor(float r, float g, float b, float a);
    void SetShaderTexture(std::string textureTag);
    void SetTextureUVScale(float u, float v);
    void SetShaderMaterial(std::string materialTag);

    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    void DestroyGLTextures();
    int  FindTextureID(std::string tag);
    int  FindTextureSlot(std::string tag);
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

private:
    struct TextureRecord { GLuint ID{ 0 }; std::string tag; };

    ShaderManager* m_pShaderManager{ nullptr };
    ShapeMeshes* m_basicMeshes{ nullptr };

    TextureRecord                m_textureIDs[16];
    int                          m_loadedTextures{ 0 };
    std::vector<OBJECT_MATERIAL> m_objectMaterials;
};
